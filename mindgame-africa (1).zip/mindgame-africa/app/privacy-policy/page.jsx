import SectionHeading from '@/components/ui/SectionHeading';

export const metadata = { title: 'Privacy Policy — MindGame Africa' };

export default function PrivacyPolicyPage() {
  return (
    <div className="mx-auto max-w-measure px-6 py-16">
      <SectionHeading title="Privacy Policy" />

      <div className="mt-6 border-l-2 border-ember pl-6 text-small text-slate">
        This is a draft policy. It requires review by a qualified professional
        before publication, to confirm it meets Nigerian Data Protection
        Regulation (NDPR) requirements and any other jurisdiction MindGame
        Africa operates in.
      </div>

      <div className="mt-10 space-y-8 text-body text-navy">
        <section>
          <h2 className="text-h4 font-semibold">What This Policy Covers</h2>
          <p className="mt-2 text-slate">
            This policy explains what personal information MindGame Africa
            collects through this website, why, and how it is used, stored
            and protected.
          </p>
        </section>

        <section>
          <h2 className="text-h4 font-semibold">Information We Collect</h2>
          <p className="mt-2 text-slate">
            Information submitted through our contact and enquiry forms:
            name, role, organisation, email, phone number, country, and the
            details of your enquiry. We do not ask for sensitive
            psychological, medical or personal information through general
            web forms.
          </p>
        </section>

        <section>
          <h2 className="text-h4 font-semibold">How We Use It</h2>
          <p className="mt-2 text-slate">
            To respond to enquiries, assess collaboration or partnership
            requests, and, where you've opted in, to send research updates,
            reports and learning opportunities through our knowledge mailing
            list. We do not sell or share your information with third parties
            for their own marketing purposes.
          </p>
        </section>

        <section>
          <h2 className="text-h4 font-semibold">Your Rights</h2>
          <p className="mt-2 text-slate">
            You may ask to see, correct, or delete the personal information
            we hold about you, or withdraw consent for us to contact you, at
            any time by writing to us.
          </p>
        </section>

        <section>
          <h2 className="text-h4 font-semibold">Contact</h2>
          <p className="mt-2 text-slate">
            Questions about this policy can be sent to the email address
            listed on our Contact page.
          </p>
        </section>
      </div>
    </div>
  );
}
