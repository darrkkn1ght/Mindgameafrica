import SectionHeading from '@/components/ui/SectionHeading';

export const metadata = { title: 'Terms of Use — MindGame Africa' };

export default function TermsOfUsePage() {
  return (
    <div className="mx-auto max-w-measure px-6 py-16">
      <SectionHeading title="Terms of Use" />

      <div className="mt-6 border-l-2 border-ember pl-6 text-small text-slate">
        This is a draft. It requires review by a qualified legal professional
        before publication.
      </div>

      <div className="mt-10 space-y-8 text-body text-navy">
        <section>
          <h2 className="text-h4 font-semibold">Acceptance of Terms</h2>
          <p className="mt-2 text-slate">
            By using mindgameafrica.com, you agree to these terms of use.
          </p>
        </section>

        <section>
          <h2 className="text-h4 font-semibold">Nature of the Content</h2>
          <p className="mt-2 text-slate">
            Content on this site — including Research, Insights and
            Resources — is provided for informational purposes and does not
            constitute individual professional advice, clinical assessment,
            or treatment. Where this site describes performance support
            services, those services are delivered under separate
            professional agreements, not through this website.
          </p>
        </section>

        <section>
          <h2 className="text-h4 font-semibold">Intellectual Property</h2>
          <p className="mt-2 text-slate">
            Content published on this site is the property of MindGame
            Africa unless otherwise credited, and may not be reproduced
            without permission.
          </p>
        </section>

        <section>
          <h2 className="text-h4 font-semibold">Limitation of Liability</h2>
          <p className="mt-2 text-slate">
            MindGame Africa makes reasonable efforts to keep this site
            accurate and available, but does not guarantee uninterrupted
            access or that all content is free of error.
          </p>
        </section>

        <section>
          <h2 className="text-h4 font-semibold">Changes to These Terms</h2>
          <p className="mt-2 text-slate">
            These terms may be updated from time to time; the current
            version will always be posted here.
          </p>
        </section>
      </div>
    </div>
  );
}
