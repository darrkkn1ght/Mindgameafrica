import { NextResponse } from 'next/server';

/**
 * Handles both the general Contact form and the Partner-With-Us inquiry
 * form (they share this endpoint; the inquiry-specific fields are simply
 * absent/undefined on the general form).
 *
 * TO WIRE UP REAL EMAIL DELIVERY:
 * Pick one and fill in the marked section below:
 *   - Resend (resend.com) — simplest, generous free tier
 *   - SendGrid
 *   - Nodemailer + your own SMTP
 * Store the API key in an environment variable (e.g. RESEND_API_KEY) in
 * .env.local — never commit real keys to the repo.
 *
 * Until that's wired up, this route validates and logs submissions so you
 * can confirm the form works end-to-end before adding real delivery.
 */

const REQUIRED_FIELDS = ['name', 'country', 'email', 'subject', 'message'];

function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export async function POST(request) {
  let data;
  try {
    data = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 });
  }

  // Honeypot: a hidden field real users never fill in. Bots that
  // auto-fill every field will trip this.
  if (data.website) {
    return NextResponse.json({ ok: true }); // pretend success, drop silently
  }

  for (const field of REQUIRED_FIELDS) {
    if (!data[field] || String(data[field]).trim() === '') {
      return NextResponse.json(
        { error: `Missing required field: ${field}` },
        { status: 400 }
      );
    }
  }

  if (!isValidEmail(data.email)) {
    return NextResponse.json({ error: 'Please provide a valid email address.' }, { status: 400 });
  }

  if (!data.consent) {
    return NextResponse.json(
      { error: 'Consent to be contacted and to data processing is required.' },
      { status: 400 }
    );
  }

  // --- WIRE UP REAL EMAIL DELIVERY HERE ---
  // Example using Resend (npm install resend, add RESEND_API_KEY to .env.local):
  //
  // import { Resend } from 'resend';
  // const resend = new Resend(process.env.RESEND_API_KEY);
  // await resend.emails.send({
  //   from: 'MindGame Africa Website <onboarding@resend.dev>',
  //   to: 'info@mindgameafrica.com', // replace with confirmed address
  //   subject: `New enquiry: ${data.subject}`,
  //   text: JSON.stringify(data, null, 2),
  // });

  console.log('Contact form submission received:', {
    name: data.name,
    email: data.email,
    inquiryType: data.inquiryType,
    subject: data.subject,
  });

  return NextResponse.json({ ok: true });
}
