'use client';

import { useState } from 'react';

const INQUIRY_TYPES = [
  { value: 'performance-engagements', label: 'Performance Engagements' },
  { value: 'research-evaluation', label: 'Research & Evaluation' },
  { value: 'university-academic-collaboration', label: 'University & Academic Collaboration' },
  { value: 'professional-education', label: 'Professional Education' },
  { value: 'practitioner-faculty-collaboration', label: 'Practitioner & Faculty Collaboration' },
  { value: 'institutional-international-partnerships', label: 'Institutional & International Partnerships' },
  { value: 'general', label: 'General Enquiry' },
];

const WHO_OPTIONS = [
  'Individual',
  'Team',
  'Staff group',
  'Students',
  'Organisation',
  'Research population',
];

const inputClass =
  'mt-1 w-full border border-slate/40 bg-parchment px-4 py-2 text-body text-navy focus:border-gold';
const labelClass = 'block text-small font-medium text-navy';

export default function ContactForm({ defaultInquiryType }) {
  const [inquiryType, setInquiryType] = useState(defaultInquiryType || 'general');
  const [status, setStatus] = useState('idle'); // idle | submitting | success | error
  const [errorMessage, setErrorMessage] = useState('');

  const isCollaborationType = inquiryType !== 'general';

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus('submitting');
    setErrorMessage('');

    const formData = new FormData(e.target);
    const payload = Object.fromEntries(formData.entries());
    payload.consent = formData.get('consent') === 'on';

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await res.json();

      if (!res.ok) {
        setStatus('error');
        setErrorMessage(result.error || 'Something went wrong. Please try again.');
        return;
      }

      setStatus('success');
    } catch {
      setStatus('error');
      setErrorMessage('Could not reach the server. Please check your connection and try again.');
    }
  }

  if (status === 'success') {
    return (
      <p className="border-t-2 border-gold pt-6 text-body-lg text-navy">
        Thank you — your enquiry has been received. We'll respond as soon as
        possible.
      </p>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Honeypot field — hidden from real users via CSS, bots that
          auto-fill every input will trip it. Do not remove. */}
      <input
        type="text"
        name="website"
        tabIndex={-1}
        autoComplete="off"
        className="absolute left-[-9999px]"
        aria-hidden="true"
      />

      {status === 'error' && (
        <p className="border-l-2 border-ember bg-ember/5 px-4 py-3 text-small text-navy">
          {errorMessage}
        </p>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        <div>
          <label className={labelClass} htmlFor="name">Name</label>
          <input className={inputClass} id="name" name="name" required />
        </div>
        <div>
          <label className={labelClass} htmlFor="role">Role / Title</label>
          <input className={inputClass} id="role" name="role" />
        </div>
        <div>
          <label className={labelClass} htmlFor="organisation">
            Organisation / Institution (if applicable)
          </label>
          <input className={inputClass} id="organisation" name="organisation" />
        </div>
        <div>
          <label className={labelClass} htmlFor="country">Country</label>
          <input className={inputClass} id="country" name="country" required />
        </div>
        <div>
          <label className={labelClass} htmlFor="email">Email</label>
          <input className={inputClass} id="email" type="email" name="email" required />
        </div>
        <div>
          <label className={labelClass} htmlFor="phone">
            Telephone / WhatsApp (optional)
          </label>
          <input className={inputClass} id="phone" name="phone" />
        </div>
      </div>

      <div>
        <label className={labelClass} htmlFor="inquiryType">Inquiry Type</label>
        <select
          id="inquiryType"
          name="inquiryType"
          className={inputClass}
          value={inquiryType}
          onChange={(e) => setInquiryType(e.target.value)}
        >
          {INQUIRY_TYPES.map((t) => (
            <option key={t.value} value={t.value}>{t.label}</option>
          ))}
        </select>
      </div>

      {/* Conditional fields — only shown for a collaboration/performance
          inquiry, not the general contact form. */}
      {isCollaborationType && (
        <div className="space-y-6 border-l-2 border-gold pl-6">
          <div>
            <label className={labelClass} htmlFor="whoConcerns">
              Who the work concerns
            </label>
            <select id="whoConcerns" name="whoConcerns" className={inputClass}>
              {WHO_OPTIONS.map((option) => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
          </div>
          <div>
            <label className={labelClass} htmlFor="description">
              Briefly describe the performance problem, research question,
              learning need or collaboration idea
            </label>
            <textarea
              id="description"
              name="description"
              rows={4}
              className={inputClass}
            />
            <p className="mt-2 text-small text-slate">
              Please don't include sensitive psychological, medical or
              personal information here — a detailed intake happens through a
              proper professional process after the enquiry is accepted.
            </p>
          </div>
          <div>
            <label className={labelClass} htmlFor="triedAlready">
              What has already been tried or established (if relevant)
            </label>
            <textarea id="triedAlready" name="triedAlready" rows={3} className={inputClass} />
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <label className={labelClass} htmlFor="desiredOutcome">Desired outcome</label>
              <input className={inputClass} id="desiredOutcome" name="desiredOutcome" />
            </div>
            <div>
              <label className={labelClass} htmlFor="timeline">Indicative timeline</label>
              <input className={inputClass} id="timeline" name="timeline" />
            </div>
          </div>
        </div>
      )}

      <div>
        <label className={labelClass} htmlFor="subject">Subject</label>
        <input className={inputClass} id="subject" name="subject" required />
      </div>

      <div>
        <label className={labelClass} htmlFor="message">Message</label>
        <textarea id="message" name="message" rows={5} className={inputClass} required />
      </div>

      <div>
        <label className={labelClass} htmlFor="preferredContact">
          Preferred contact method
        </label>
        <select id="preferredContact" name="preferredContact" className={inputClass}>
          <option value="email">Email</option>
          <option value="phone">Phone</option>
          <option value="whatsapp">WhatsApp</option>
        </select>
      </div>

      <label className="flex items-start gap-3 text-small text-slate">
        <input type="checkbox" name="consent" required className="mt-1" />
        I consent to MindGame Africa processing this information to respond
        to my enquiry, in line with the Privacy Policy.
      </label>

      <button
        type="submit"
        disabled={status === 'submitting'}
        className="bg-gold px-6 py-3 text-small font-medium text-navy hover:bg-gold/90 disabled:opacity-60"
      >
        {status === 'submitting' ? 'Sending…' : 'Send Enquiry'}
      </button>
    </form>
  );
}
