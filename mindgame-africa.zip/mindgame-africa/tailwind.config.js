/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        // MindGame Africa design tokens — do not add colors outside this set.
        navy: '#0F1A2B',      // Ink Navy — primary text, dark sections
        parchment: '#F2EEE3', // Parchment — main reading background
        gold: '#C8952E',      // Signal Gold — primary CTA / emphasis only
        ember: '#B23A20',     // Ember — secondary accent, data markers
        green: '#3B6B4F',     // Field Green — research/growth states
        slate: '#5B6472',     // Slate — secondary text, borders
      },
      fontFamily: {
        serif: ['"Source Serif 4"', 'ui-serif', 'Georgia', 'serif'],
        sans: ['"IBM Plex Sans"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        // A deliberate type scale (roughly major-third, 1.25 ratio)
        'display': ['3.815rem', { lineHeight: '1.05', letterSpacing: '-0.01em' }],
        'h1': ['3.052rem', { lineHeight: '1.1' }],
        'h2': ['2.441rem', { lineHeight: '1.15' }],
        'h3': ['1.953rem', { lineHeight: '1.2' }],
        'h4': ['1.563rem', { lineHeight: '1.3' }],
        'body-lg': ['1.25rem', { lineHeight: '1.6' }],
        'body': ['1rem', { lineHeight: '1.65' }],
        'small': ['0.875rem', { lineHeight: '1.5' }],
      },
      maxWidth: {
        'measure': '38rem', // ~70-78 characters at body size
      },
    },
  },
  plugins: [],
};
