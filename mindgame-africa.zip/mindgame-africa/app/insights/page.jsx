import Link from 'next/link';
import SectionHeading from '@/components/ui/SectionHeading';
import insightsData from '@/content/insights.json';

export const metadata = { title: 'Insights — MindGame Africa' };

export default function InsightsPage() {
  const { articles } = insightsData;

  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <SectionHeading
        title="Insights"
        supporting="A living knowledge platform between formal research publications — demonstrating thinking, research translation and applied judgement."
      />

      {articles.length === 0 ? (
        <div className="mt-12 border border-dashed border-slate/40 p-6 text-slate">
          No articles published yet.
        </div>
      ) : (
        <ul className="mt-12 divide-y divide-slate/20 border-t border-slate/20">
          {articles.map((article) => (
            <li key={article.slug} className="py-8">
              <Link href={`/insights/${article.slug}`} className="group block">
                <h2 className="text-h3 font-semibold text-navy group-hover:text-gold">
                  {article.title}
                </h2>
                <p className="mt-2 text-small text-slate">
                  By {article.author}
                  {article.date ? `, ${article.date}` : ''}
                  {article.readingTime ? ` (${article.readingTime} min read)` : ''}
                </p>
              </Link>
            </li>
          ))}
        </ul>
      )}
      {/* Categories only shown once there's enough content to justify them —
          left out of this component entirely until then, per the brief. */}
    </div>
  );
}
