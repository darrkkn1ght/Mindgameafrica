import { notFound } from 'next/navigation';
import insightsData from '@/content/insights.json';

export function generateStaticParams() {
  return insightsData.articles.map((a) => ({ slug: a.slug }));
}

export default function ArticlePage({ params }) {
  const article = insightsData.articles.find((a) => a.slug === params.slug);
  if (!article) return notFound();

  return (
    <article className="mx-auto max-w-measure px-6 py-16">
      <h1 className="font-display text-h1 font-semibold text-navy">
        {article.title}
      </h1>
      <p className="mt-4 text-small text-slate">By {article.author}</p>
      <div className="mt-10 space-y-6 text-body text-navy">
        {article.body}
      </div>
    </article>
  );
}
