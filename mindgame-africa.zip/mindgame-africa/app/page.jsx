import Button from '@/components/ui/Button';
import SectionHeading from '@/components/ui/SectionHeading';
import PillarBlock from '@/components/PillarBlock';
import { HeroDiagram } from '@/components/ui/Diagram';

const PILLARS = [
  {
    size: 'large',
    title: 'Applied Performance Practice',
    body: 'Evidence-informed assessment and intervention for athletes, coaches, teams and other high-pressure performers, with particular strength in performance psychology, mental performance and behavioural performance.',
  },
  {
    size: 'large',
    title: 'Performance Science',
    body: 'A multidisciplinary approach to understanding performance through the interaction of psychological, behavioural, physiological, biomechanical, technical, analytical and contextual factors.',
  },
  {
    size: 'small',
    title: 'Research & Knowledge',
    body: 'Original and commissioned research, programme evaluation, evidence reviews, frameworks, reports and knowledge translation focused on real performance questions.',
  },
  {
    size: 'small',
    title: 'Education & Professional Development',
    body: 'Short courses, workshops, masterclasses and structured learning for practitioners, coaches, students and sport professionals, with clear learning outcomes and accurate certificate language.',
  },
  {
    size: 'small',
    title: 'Practitioner Development',
    body: 'Supervised learning, mentorship, case discussion, observation, practicum, internships and applied-practice pathways that help emerging professionals move from qualification toward competence.',
  },
];

const WHO_WE_WORK_WITH = [
  'Athletes and other high-pressure performers',
  'Teams, clubs and academies',
  'Coaches and performance staff',
  'Sport federations, associations and performance organisations',
  'Schools and universities',
  'Researchers and academic departments',
  'Performance practitioners and emerging professionals',
  "Corporate and other high-pressure organisations, where the work falls within MindGame Africa's genuine competence",
  'International institutions interested in research, education, faculty exchange or technical collaboration',
];

export default function HomePage() {
  return (
    <>
      {/* HERO — asymmetric two-column, left-aligned. One deliberate motion
          moment on load; nothing else on the page animates on scroll. */}
      <section className="mx-auto max-w-6xl px-6 pb-16 pt-16 md:pt-24">
        <div className="grid gap-10 md:grid-cols-5 md:gap-16">
          <div className="hero-reveal md:col-span-3">
            <h1 className="text-h1 font-semibold text-navy md:text-display">
              Developing the Human and Intellectual Infrastructure of
              Performance in Africa.
            </h1>
          </div>
          <div className="hero-reveal-delay flex flex-col justify-between md:col-span-2">
            <p className="text-body-lg text-slate">
              MindGame Africa connects performance science, research,
              education and professional practice to help athletes, teams,
              coaches, organisations and practitioners understand performance
              problems, develop capability and improve what happens in
              practice.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Button href="/services" variant="primary">
                Explore What We Do
              </Button>
              <Button href="/partner-with-us" variant="secondary">
                Work With MindGame Africa
              </Button>
            </div>
          </div>
        </div>
        <div className="mt-14 h-56 w-full opacity-90 md:h-72">
          <HeroDiagram />
        </div>
      </section>

      {/* CORE INSTITUTIONAL PILLARS — asymmetric weighting, not a card grid */}
      <section className="border-t border-slate/20 bg-parchment px-6 py-16">
        <div className="mx-auto max-w-6xl">
          <SectionHeading
            title="What MindGame Africa Does"
            supporting="Five institutional pillars, not a catalogue of services."
          />
          <div className="mt-10 grid gap-10 md:grid-cols-2">
            {PILLARS.filter((p) => p.size === 'large').map((p) => (
              <PillarBlock key={p.title} {...p} />
            ))}
          </div>
          <div className="mt-10 grid gap-8 border-t border-slate/20 pt-10 md:grid-cols-3">
            {PILLARS.filter((p) => p.size === 'small').map((p) => (
              <PillarBlock key={p.title} {...p} />
            ))}
          </div>
        </div>
      </section>

      {/* WHO WE WORK WITH — plain list, not icon-cards */}
      <section className="px-6 py-16">
        <div className="mx-auto max-w-6xl">
          <SectionHeading title="Who We Work With" />
          <ul className="mt-8 grid max-w-4xl gap-x-10 gap-y-3 text-body text-navy md:grid-cols-2">
            {WHO_WE_WORK_WITH.map((item) => (
              <li key={item} className="border-b border-slate/15 pb-3">
                {item}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* FEATURED WORK — editable via CMS later; honest placeholder now */}
      <section className="border-t border-slate/20 bg-navy px-6 py-16 text-parchment">
        <div className="mx-auto max-w-6xl">
          <p className="text-small uppercase tracking-normal text-parchment/60">
            Featured work
          </p>
          <p className="mt-3 max-w-measure text-body-lg text-parchment/80">
            This space will feature a current service, programme, research
            project or initiative — set and changed through the CMS as real
            work is confirmed.
          </p>
        </div>
      </section>

      {/* RESEARCH PREVIEW */}
      <section className="px-6 py-16">
        <div className="mx-auto max-w-6xl">
          <SectionHeading
            title="Research & Knowledge"
            supporting="Current research, reports and evidence-informed thinking — not hidden as an academic afterthought."
          />
          <div className="mt-8 border border-dashed border-slate/40 p-6 text-slate">
            Research content will appear here once published or approved.
          </div>
          <div className="mt-6">
            <Button href="/research" variant="secondary">
              Visit Research
            </Button>
          </div>
        </div>
      </section>

      {/* EDUCATION PREVIEW */}
      <section className="border-t border-slate/20 px-6 py-16">
        <div className="mx-auto max-w-6xl">
          <SectionHeading
            title="Education & Professional Development"
            supporting="Current workshops, short courses and learning opportunities, when available."
          />
          <div className="mt-8 border border-dashed border-slate/40 p-6 text-slate">
            Programme listings will appear here as they are confirmed —
            audience, format, duration and status for each.
          </div>
          <div className="mt-6">
            <Button href="/education" variant="secondary">
              Visit Education & Professional Development
            </Button>
          </div>
        </div>
      </section>

      {/* PEOPLE PREVIEW */}
      <section className="px-6 py-16">
        <div className="mx-auto max-w-6xl">
          <SectionHeading title="People" />
          <div className="mt-8 grid gap-6 md:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="border border-dashed border-slate/40 p-5">
                <div className="mb-4 flex h-32 w-full items-center justify-center bg-slate/10 text-small text-slate">
                  Photo placeholder
                </div>
                <p className="text-small text-slate">Profile — to be supplied</p>
              </div>
            ))}
          </div>
          <div className="mt-6">
            <Button href="/people" variant="secondary">
              Meet the People
            </Button>
          </div>
        </div>
      </section>

      {/* CLOSING CTA */}
      <section className="border-t border-slate/20 bg-parchment px-6 py-20">
        <div className="mx-auto max-w-3xl text-center">
          <p className="font-display text-h3 font-semibold text-navy">
            Have a performance problem, research question, learning need or
            collaboration idea? Start the right conversation with MindGame
            Africa.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Button href="/contact" variant="primary">
              Work With Us
            </Button>
            <Button href="/partner-with-us" variant="secondary">
              Partner With Us
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
