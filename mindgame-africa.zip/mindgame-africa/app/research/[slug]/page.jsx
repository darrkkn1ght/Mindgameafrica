import { notFound } from 'next/navigation';
import researchData from '@/content/research.json';

export function generateStaticParams() {
  return researchData.outputs.map((o) => ({ slug: o.slug }));
}

export default function ResearchOutputPage({ params }) {
  const output = researchData.outputs.find((o) => o.slug === params.slug);
  if (!output) return notFound();

  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <p className="text-small text-slate">
        {output.type}
        {output.date ? ` (${output.date})` : ''}
      </p>
      <h1 className="mt-3 font-display text-h1 font-semibold text-navy">
        {output.title}
      </h1>
      {output.authors && (
        <p className="mt-4 text-body text-slate">{output.authors}</p>
      )}
      {output.abstract && (
        <p className="mt-8 max-w-measure text-body-lg text-slate">
          {output.abstract}
        </p>
      )}
      {output.downloadUrl && (
        <a
          href={output.downloadUrl}
          className="mt-8 inline-block border border-navy px-6 py-3 text-small font-medium text-navy hover:bg-navy hover:text-parchment"
        >
          Download report
        </a>
      )}
    </div>
  );
}
