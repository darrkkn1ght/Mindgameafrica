import Link from 'next/link';
import SectionHeading from '@/components/ui/SectionHeading';
import researchData from '@/content/research.json';

export const metadata = { title: 'Research — MindGame Africa' };

export default function ResearchPage() {
  const { themes, outputs } = researchData;

  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <SectionHeading
        title="Research"
        supporting="MindGame Africa intends not only to consume knowledge, but to produce, test, translate and apply it."
      />

      <section className="mt-14">
        <h2 className="text-h3 font-semibold text-navy">Research Themes</h2>
        {/* Structured grid rhythm — appropriate here since this content is
            evidence-heavy, unlike the asymmetric editorial rhythm used on About. */}
        <ul className="mt-6 grid gap-x-10 gap-y-4 border-t border-slate/20 pt-6 md:grid-cols-2">
          {themes.map((theme) => (
            <li key={theme} className="border-b border-slate/15 pb-4 text-body text-navy">
              {theme}
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-14">
        <h2 className="text-h3 font-semibold text-navy">Published & Ongoing Research</h2>
        {outputs.length === 0 ? (
          <div className="mt-6 border border-dashed border-slate/40 p-6 text-slate">
            No published outputs yet. This section will list reports, articles
            and datasets as they are approved for publication — including, in
            future, a flagship publication such as a State of African Sport
            Performance report.
          </div>
        ) : (
          <ul className="mt-6 divide-y divide-slate/20 border-t border-slate/20">
            {outputs.map((output) => (
              <li key={output.slug} className="py-6">
                <Link href={`/research/${output.slug}`} className="text-h4 font-semibold text-navy hover:text-gold">
                  {output.title}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
