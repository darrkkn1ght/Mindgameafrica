import Link from 'next/link';
import SectionHeading from '@/components/ui/SectionHeading';

const ROUTES = [
  {
    slug: 'performance-engagements',
    title: 'Performance Engagements',
    body: 'For athletes, teams, clubs, academies and organisations that need assessment, performance support or a structured intervention.',
  },
  {
    slug: 'research-evaluation',
    title: 'Research & Evaluation',
    body: 'For clubs, federations, universities, organisations and programmes that need commissioned research, evaluation or a research collaboration.',
  },
  {
    slug: 'university-academic-collaboration',
    title: 'University & Academic Collaboration',
    body: 'For departments, universities and researchers interested in research, student placements, guest teaching, joint projects or knowledge exchange.',
  },
  {
    slug: 'professional-education',
    title: 'Professional Education',
    body: 'For organisations or groups interested in workshops, short courses, continuing professional development or tailored learning.',
  },
  {
    slug: 'practitioner-faculty-collaboration',
    title: 'Practitioner & Faculty Collaboration',
    body: 'For qualified academics and practitioners interested in teaching, research, applied projects, mentorship or future network roles.',
  },
  {
    slug: 'institutional-international-partnerships',
    title: 'Institutional & International Partnerships',
    body: 'For credible organisations interested in longer-term collaboration around performance science, research, education, practitioner development or technical cooperation.',
  },
];

export const metadata = { title: 'Partner With Us — MindGame Africa' };

export default function PartnerWithUsPage() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <SectionHeading
        title="Partner With Us"
        supporting="Each route leads to a tailored enquiry so we receive enough context to decide whether the opportunity fits our mandate."
      />
      <div className="mt-12 grid gap-8 md:grid-cols-2">
        {ROUTES.map((route) => (
          <Link
            key={route.slug}
            href={`/contact?type=${route.slug}`}
            className="group block border-t border-slate/30 pt-6 hover:border-gold"
          >
            <h2 className="text-h4 font-semibold text-navy group-hover:text-gold">
              {route.title}
            </h2>
            <p className="mt-2 text-body text-slate">{route.body}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
