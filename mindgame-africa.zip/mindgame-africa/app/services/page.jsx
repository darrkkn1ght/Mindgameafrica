import Link from 'next/link';
import SectionHeading from '@/components/ui/SectionHeading';
import services from '@/content/services.json';

export const metadata = { title: 'Performance Services — MindGame Africa' };

export default function ServicesPage() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <SectionHeading
        title="Performance Services"
        supporting="An applied-practice hub — not a catalogue of motivational workshops."
      />
      <ul className="mt-12 divide-y divide-slate/20 border-t border-slate/20">
        {services.map((service) => (
          <li key={service.slug} className="py-8">
            <Link href={`/services/${service.slug}`} className="group block">
              <h2 className="text-h3 font-semibold text-navy group-hover:text-gold">
                {service.title}
              </h2>
              <p className="mt-3 max-w-measure text-body text-slate">
                {service.problem}
              </p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
