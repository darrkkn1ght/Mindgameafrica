import { notFound } from 'next/navigation';
import Button from '@/components/ui/Button';
import services from '@/content/services.json';

export function generateStaticParams() {
  return services.map((s) => ({ slug: s.slug }));
}

export function generateMetadata({ params }) {
  const service = services.find((s) => s.slug === params.slug);
  return { title: service ? `${service.title} — MindGame Africa` : 'Service — MindGame Africa' };
}

// Every service page follows this exact 10-part structure from the brief.
const FIELDS = [
  ['problem', 'The Performance Problem or Question'],
  ['whoFor', 'Who It Is For'],
  ['intake', 'What Assessment or Intake Comes First'],
  ['scope', 'Scope of Work'],
  ['delivery', 'How the Work Is Delivered'],
  ['outputs', 'Typical Outputs / Deliverables'],
  ['evaluation', 'How Progress or Outcomes May Be Evaluated'],
  ['disciplines', 'Relevant Practitioner Disciplines'],
  ['boundaries', 'Professional Boundaries'],
];

export default function ServicePage({ params }) {
  const service = services.find((s) => s.slug === params.slug);
  if (!service) return notFound();

  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <h1 className="font-display text-h1 font-semibold text-navy">
        {service.title}
      </h1>

      <div className="mt-12 grid gap-12 md:grid-cols-3">
        <div className="space-y-10 md:col-span-2">
          {FIELDS.map(([key, label]) =>
            service[key] ? (
              <div key={key}>
                <h2 className="text-h4 font-semibold text-navy">{label}</h2>
                <p className="mt-2 max-w-measure text-body text-slate">
                  {service[key]}
                </p>
              </div>
            ) : null
          )}
        </div>

        <aside className="md:col-span-1">
          <div className="sticky top-8 border-t-2 border-gold pt-6">
            <p className="text-body text-slate">
              Ready to talk through this need?
            </p>
            <div className="mt-4">
              <Button href="/partner-with-us" variant="primary">
                Discuss This Performance Need
              </Button>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
