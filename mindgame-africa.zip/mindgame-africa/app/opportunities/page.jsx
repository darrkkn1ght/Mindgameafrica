import SectionHeading from '@/components/ui/SectionHeading';

const OPPORTUNITY_TYPES = [
  'Internships and SIWES placements',
  'Supervised practicum opportunities',
  'Research attachments and participation',
  'Student research opportunities',
  'Faculty or visiting-faculty calls',
  'Practitioner and research-associate opportunities',
  'Mentorship / supervision pathways when formally structured',
  'Calls for collaborators or specialist contributors',
];

export const metadata = { title: 'Opportunities — MindGame Africa' };

export default function OpportunitiesPage() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <SectionHeading
        title="Opportunities"
        supporting="A home for genuine openings as they are activated — not a pretence of a large practitioner academy that doesn't yet exist."
      />
      <ul className="mt-12 divide-y divide-slate/20 border-t border-slate/20">
        {OPPORTUNITY_TYPES.map((type) => (
          <li key={type} className="flex items-center justify-between py-6 text-body text-navy">
            <span>{type}</span>
            <span className="text-small text-slate">None currently open</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
