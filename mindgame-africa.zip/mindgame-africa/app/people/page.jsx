import SectionHeading from '@/components/ui/SectionHeading';
import PersonCard from '@/components/PersonCard';
import peopleData from '@/content/people.json';

export const metadata = { title: 'People — MindGame Africa' };

// Categories the data structure supports. The public filter UI stays
// dormant (not rendered) until the network is large enough to justify it —
// per the brief. Grouping by category is still used for display order.
const CATEGORIES = [
  'Leadership',
  'Faculty',
  'Practitioners / Specialists',
  'Research Associates',
  'Practitioner Mentors / Supervisors',
  'Technical Advisors',
  'Visiting Faculty / Visiting Practitioners',
];

export default function PeoplePage() {
  const { people } = peopleData;

  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <SectionHeading
        title="People"
        supporting="A networked expert model — not every listed person is full-time staff."
      />

      {people.length === 0 ? (
        <div className="mt-12 border border-dashed border-slate/40 p-6 text-slate">
          Profiles will appear here as leadership, faculty, practitioner,
          research and advisor appointments are confirmed.
        </div>
      ) : (
        CATEGORIES.map((category) => {
          const inCategory = people.filter((p) => p.category === category);
          if (inCategory.length === 0) return null;
          return (
            <section key={category} className="mt-14">
              <h2 className="text-h3 font-semibold text-navy">{category}</h2>
              <div className="mt-8 grid gap-8 md:grid-cols-3">
                {inCategory.map((person) => (
                  <PersonCard key={person.name} person={person} />
                ))}
              </div>
            </section>
          );
        })
      )}
    </div>
  );
}
