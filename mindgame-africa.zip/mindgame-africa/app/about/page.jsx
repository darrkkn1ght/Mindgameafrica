import SectionHeading from '@/components/ui/SectionHeading';
import { AppliedApproachDiagram } from '@/components/ui/Diagram';
import PersonCard from '@/components/PersonCard';
import peopleData from '@/content/people.json';

export const metadata = { title: 'About — MindGame Africa' };

export default function AboutPage() {
  const leadership = peopleData.people.filter((p) => p.category === 'Leadership');

  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      {/* WHO WE ARE */}
      <section className="max-w-measure">
        <h1 className="font-display text-h1 font-semibold text-navy">Who We Are</h1>
        <p className="mt-6 text-body-lg text-slate">
          MindGame Africa is a performance science, research, education and
          professional-practice institution being built to strengthen the
          human and intellectual capability behind performance in Africa. We
          connect evidence with practice by working on performance problems,
          producing and translating knowledge, developing practitioners and
          creating stronger routes between universities, specialists and real
          performance environments.
        </p>
      </section>

      {/* WHY WE EXIST */}
      <section className="mt-20 max-w-measure">
        <SectionHeading title="Why We Exist" />
        <p className="mt-6 text-body text-slate">
          Exceptional performance does not depend on talent alone. It also
          depends on the quality of knowledge surrounding performers, the
          competence of practitioners, the behaviour of coaches, the quality
          of assessment and intervention, the strength of research, and the
          routes through which evidence becomes everyday practice.
        </p>
        <p className="mt-4 text-body text-slate">
          MindGame Africa exists to help deepen that capability in African
          performance environments while remaining connected to credible
          global science and professional standards.
        </p>
      </section>

      {/* DEFINING IDEA — visually distinct callout */}
      <section className="mt-20 border-l-2 border-gold pl-8">
        <p className="max-w-measure font-display text-h3 text-navy">
          The same visible problem can have different causes, and the
          discipline required should be determined by the problem — not by
          the service someone wants to sell.
        </p>
      </section>

      {/* APPLIED APPROACH — the genuine sequence */}
      <section className="mt-20">
        <SectionHeading
          title="Our Applied Approach"
          supporting="A defined sequence — not a slogan."
        />
        <div className="mt-10">
          <AppliedApproachDiagram />
        </div>
      </section>

      {/* INSTITUTIONAL DIRECTION — future ambition, worded as direction */}
      <section className="mt-20 max-w-measure">
        <SectionHeading title="Institutional Direction" />
        <p className="mt-6 text-body text-slate">
          MindGame Africa is being built over time. Its long-term ambition
          includes a stronger faculty and practitioner network, recurring
          professional programmes, formal university relationships,
          supervised practitioner pathways, a larger African
          performance-research network and, when justified by real capability
          and demand, multidisciplinary laboratory and performance-science
          infrastructure. None of this is presented as existing today — it is
          direction, not current capability.
        </p>
      </section>

      {/* LEADERSHIP */}
      <section className="mt-20">
        <SectionHeading title="Leadership" />
        <div className="mt-10 grid gap-8 md:grid-cols-3">
          {leadership.length > 0
            ? leadership.map((person) => (
                <PersonCard key={person.name} person={person} />
              ))
            : Array.from({ length: 2 }).map((_, i) => (
                <PersonCard key={i} isPlaceholder />
              ))}
        </div>
      </section>
    </div>
  );
}
