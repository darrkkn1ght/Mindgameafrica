import SectionHeading from '@/components/ui/SectionHeading';
import ContactForm from './ContactForm';

export const metadata = { title: 'Contact — MindGame Africa' };

export default function ContactPage({ searchParams }) {
  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <SectionHeading title="Contact" />
      <p className="mt-4 text-body text-slate">
        {/* Do not invent a phone number, address, or social URL — leave as
            "to be supplied" until real values are confirmed. */}
        Email: to be supplied (final @mindgameafrica.com address pending)
      </p>
      <div className="mt-12">
        <ContactForm defaultInquiryType={searchParams?.type} />
      </div>
    </div>
  );
}
