import { notFound } from 'next/navigation';
import Button from '@/components/ui/Button';
import programmesData from '@/content/programmes.json';

export function generateStaticParams() {
  return programmesData.programmes.map((p) => ({ slug: p.slug }));
}

// Every programme page supports this exact field set from the brief.
const FIELDS = [
  ['audience', 'Who This Programme Is For'],
  ['entryRequirements', 'Entry Requirements'],
  ['learningOutcomes', 'Learning Outcomes'],
  ['curriculum', 'Curriculum / Modules'],
  ['faculty', 'Faculty / Instructors'],
  ['format', 'Format'],
  ['duration', 'Duration and Schedule'],
  ['assessment', 'Assessment / Participation Requirements'],
  ['fees', 'Fees and Registration'],
];

export default function ProgrammePage({ params }) {
  const programme = programmesData.programmes.find((p) => p.slug === params.slug);
  if (!programme) return notFound();

  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <p className="text-small text-gold">{programme.status}</p>
      <h1 className="mt-2 font-display text-h1 font-semibold text-navy">
        {programme.title}
      </h1>

      <div className="mt-12 grid gap-12 md:grid-cols-3">
        <div className="space-y-10 md:col-span-2">
          {FIELDS.map(([key, label]) =>
            programme[key] ? (
              <div key={key}>
                <h2 className="text-h4 font-semibold text-navy">{label}</h2>
                <p className="mt-2 max-w-measure text-body text-slate">
                  {programme[key]}
                </p>
              </div>
            ) : null
          )}

          {/* Certificate wording rendered from data, never hard-coded to
              imply accreditation that hasn't been secured. */}
          <div>
            <h2 className="text-h4 font-semibold text-navy">Certificate</h2>
            <p className="mt-2 max-w-measure text-body text-slate">
              {programme.certificateWording ||
                'Certificate of completion / participation / professional development.'}
            </p>
          </div>
        </div>

        <aside className="md:col-span-1">
          <div className="sticky top-8 border-t-2 border-gold pt-6">
            <Button href="/contact" variant="primary">
              Register Interest
            </Button>
          </div>
        </aside>
      </div>
    </div>
  );
}
