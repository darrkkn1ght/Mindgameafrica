import Link from 'next/link';
import SectionHeading from '@/components/ui/SectionHeading';
import programmesData from '@/content/programmes.json';

export const metadata = { title: 'Education & Professional Development — MindGame Africa' };

export default function EducationPage() {
  const { programmes } = programmesData;

  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <SectionHeading
        title="Education & Professional Development"
        supporting="Workshops, masterclasses and structured learning for practitioners, coaches, students and sport professionals."
      />

      {programmes.length === 0 ? (
        <div className="mt-12 border border-dashed border-slate/40 p-6 text-slate">
          No programmes are open yet. This section will list confirmed
          workshops and courses as dates, fees and registration details are
          finalised.
        </div>
      ) : (
        <ul className="mt-12 divide-y divide-slate/20 border-t border-slate/20">
          {programmes.map((programme) => (
            <li key={programme.slug} className="py-8">
              <Link href={`/education/${programme.slug}`} className="group block">
                <p className="text-small text-gold">{programme.status}</p>
                <h2 className="mt-1 text-h3 font-semibold text-navy group-hover:text-gold">
                  {programme.title}
                </h2>
                <p className="mt-2 text-body text-slate">{programme.audience}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}

      <div className="mt-12 border-l-2 border-ember pl-6 text-small text-slate">
        Certificates are described accurately as certificates of completion,
        participation or professional development, unless formal
        accreditation has been secured.
      </div>
    </div>
  );
}
