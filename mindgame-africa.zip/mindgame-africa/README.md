# MindGame Africa Website

Next.js (App Router) starter build, structured around the design system and
information architecture from the MindGame Africa Website Design &
Development Brief.

## Run it locally

```bash
npm install
npm run dev
```

Then open http://localhost:3000

## Deploy for free

Push this folder to a GitHub repo, then either:
- **Vercel** (built by the makers of Next.js — easiest): import the repo at
  vercel.com/new, it auto-detects Next.js, no config needed.
- **Netlify**: import the repo, build command `npm run build`, publish
  directory `.next` (Netlify's Next.js runtime handles the rest).

## What's built

- Homepage, About, Services (hub + 5 service pages), Research (hub +
  output template), Education & Professional Development (hub + programme
  template), Insights (hub + article template), People, Opportunities,
  Partner With Us, Contact (with conditional inquiry form).
- All real launch-scope pages from the brief's §22 table.

## Where content lives (`/content/*.json`)

This is your placeholder CMS. Edit these JSON files directly to add real
services, research outputs, programmes, people and articles — no code
changes needed for content updates. When you're ready for a real CMS
(Sanity, Contentful, etc.), swap the JSON imports for API calls; the page
components don't need to change.

## Still to do before launch

- Replace placeholder photography (`/public/images`) with real MindGame
  Africa photography once supplied.
- Fill in real leadership/faculty/practitioner profiles in
  `content/people.json`.
- Confirm final email address and social URLs in `components/layout/Footer.jsx`
  and `app/contact/page.jsx` — currently marked "to be supplied".
- Wire the contact form to a real submission handler (currently simulates
  success client-side only).
- Write Privacy Policy / Terms of Use pages (linked from footer, not yet
  built).
- Add analytics/event tracking per brief §18.
