import Link from 'next/link';

const NAV_LINKS = [
  { href: '/about', label: 'About' },
  { href: '/services', label: 'Performance Services' },
  { href: '/research', label: 'Research' },
  { href: '/education', label: 'Education & Professional Development' },
  { href: '/insights', label: 'Insights' },
  { href: '/people', label: 'People' },
  { href: '/opportunities', label: 'Opportunities' },
  { href: '/partner-with-us', label: 'Partner With Us' },
  { href: '/contact', label: 'Contact' },
];

export default function Header() {
  return (
    <header className="border-b border-slate/20 bg-parchment">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <Link href="/" className="font-display text-h4 font-semibold text-navy">
          MindGame Africa
        </Link>
        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex flex-wrap items-center gap-6 text-small text-navy">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="hover:text-gold">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        {/* Mobile nav: a simple details/summary disclosure — no JS needed */}
        <details className="lg:hidden">
          <summary className="cursor-pointer list-none text-small font-medium text-navy">
            Menu
          </summary>
          <ul className="absolute left-0 right-0 z-10 mt-4 space-y-3 border-b border-slate/20 bg-parchment px-6 py-6 text-body">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="block hover:text-gold">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </details>
      </div>
    </header>
  );
}
