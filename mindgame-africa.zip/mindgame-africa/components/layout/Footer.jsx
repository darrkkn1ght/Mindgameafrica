import Link from 'next/link';

const QUICK_LINKS = [
  { href: '/services', label: 'Performance Services' },
  { href: '/research', label: 'Research' },
  { href: '/education', label: 'Education & Professional Development' },
  { href: '/insights', label: 'Insights' },
  { href: '/opportunities', label: 'Opportunities' },
  { href: '/partner-with-us', label: 'Partner With Us' },
  { href: '/contact', label: 'Contact' },
];

export default function Footer() {
  return (
    <footer className="border-t border-slate/20 bg-navy text-parchment">
      <div className="mx-auto max-w-6xl px-6 py-12">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <p className="font-display text-h4 font-semibold">MindGame Africa</p>
            <p className="mt-3 max-w-measure text-small text-parchment/80">
              Performance science, research, education and professional practice
              for stronger performance capability in Africa.
            </p>
          </div>
          <nav aria-label="Footer">
            <ul className="space-y-2 text-small">
              {QUICK_LINKS.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="hover:text-gold">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
          <div className="text-small text-parchment/80">
            {/* Social links, once supplied, go here — do not invent URLs. */}
            <p>
              <Link href="/privacy-policy" className="hover:text-gold">
                Privacy Policy
              </Link>
            </p>
            <p className="mt-2">
              <Link href="/terms-of-use" className="hover:text-gold">
                Terms of Use
              </Link>
            </p>
          </div>
        </div>
        <p className="mt-10 text-small text-parchment/60">
          © {new Date().getFullYear()} MindGame Africa. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
