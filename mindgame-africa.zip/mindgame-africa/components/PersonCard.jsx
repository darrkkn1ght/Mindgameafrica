/**
 * Reused on About (Leadership) and the People page. When real profiles
 * aren't supplied yet, isPlaceholder renders a clearly-labeled stand-in
 * rather than an invented name/bio.
 */
export default function PersonCard({ person, isPlaceholder = false }) {
  if (isPlaceholder) {
    return (
      <div className="border border-dashed border-slate/40 p-5">
        <div className="mb-4 flex h-40 w-full items-center justify-center bg-slate/10 text-small text-slate">
          Photo placeholder
        </div>
        <p className="text-body font-medium text-slate">Name — to be supplied</p>
        <p className="text-small text-slate/70">Role/category — to be supplied</p>
      </div>
    );
  }

  const { name, role, category, discipline, bio, photoUrl } = person;

  return (
    <div className="border-t border-slate/30 pt-5">
      <div className="mb-4 h-40 w-full overflow-hidden bg-slate/10">
        {photoUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={photoUrl} alt={name} className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full items-center justify-center text-small text-slate">
            Photo pending
          </div>
        )}
      </div>
      <p className="text-body-lg font-medium text-navy">{name}</p>
      <p className="text-small text-gold">{category}</p>
      {discipline && <p className="text-small text-slate">{discipline}</p>}
      {role && <p className="mt-1 text-small text-slate">{role}</p>}
      {bio && <p className="mt-3 text-body text-slate">{bio}</p>}
    </div>
  );
}
