/**
 * The five institutional pillars are NOT a sequence, so this deliberately
 * avoids numbered-card-grid treatment. "size=large" pillars (Applied
 * Performance Practice, Performance Science) get more visual weight because
 * the brief names them as the core disciplines; the rest sit in a tighter
 * row beneath.
 */
export default function PillarBlock({ title, body, size = 'small' }) {
  const isLarge = size === 'large';
  return (
    <div
      className={
        isLarge
          ? 'border-t-2 border-gold pt-6'
          : 'border-t border-slate/30 pt-5'
      }
    >
      <h3 className={isLarge ? 'text-h3 font-semibold text-navy' : 'text-h4 font-semibold text-navy'}>
        {title}
      </h3>
      <p className={`mt-3 max-w-measure text-slate ${isLarge ? 'text-body-lg' : 'text-body'}`}>
        {body}
      </p>
    </div>
  );
}
