/**
 * HeroDiagram: a quiet abstract dot/line graphic standing in for photography
 * we don't have yet. Deliberately not a stock photo, not a gradient blob.
 */
export function HeroDiagram() {
  const nodes = [
    [40, 60], [140, 30], [230, 90], [90, 150], [200, 180], [280, 60], [60, 220],
  ];
  return (
    <svg
      viewBox="0 0 320 260"
      className="h-full w-full"
      role="img"
      aria-label="Abstract diagram representing performance data and research"
    >
      {nodes.map(([x1, y1], i) =>
        nodes.slice(i + 1).map(([x2, y2], j) => (
          <line
            key={`${i}-${j}`}
            x1={x1} y1={y1} x2={x2} y2={y2}
            stroke="#C8952E"
            strokeOpacity="0.15"
            strokeWidth="1"
          />
        ))
      )}
      {nodes.map(([x, y], i) => (
        <circle
          key={i}
          cx={x} cy={y} r={i % 3 === 0 ? 5 : 3}
          fill={i % 3 === 0 ? '#C8952E' : '#3B6B4F'}
          fillOpacity="0.8"
        />
      ))}
    </svg>
  );
}

/**
 * AppliedApproachDiagram: the ONE place numbered markers are earned —
 * this content is a genuine sequence (Define -> Assess -> Diagnose ->
 * Design -> Apply -> Measure -> Adjust).
 */
const STEPS = [
  { n: '01', title: 'Define', body: 'Define the performance problem or question clearly.' },
  { n: '02', title: 'Assess', body: 'Assess the performer, team or environment using evidence appropriate to that question.' },
  { n: '03', title: 'Diagnose', body: 'Diagnose the factors most likely to be producing the observed performance.' },
  { n: '04', title: 'Design', body: 'Design an intervention, programme, research response or learning solution around those factors.' },
  { n: '05', title: 'Apply', body: 'Apply the work with appropriate specialist competence and professional boundaries.' },
  { n: '06', title: 'Measure', body: 'Measure what changes, what does not, and what the evidence allows us to conclude.' },
  { n: '07', title: 'Adjust', body: 'Adjust, document and translate useful learning back into practice.' },
];

export function AppliedApproachDiagram() {
  return (
    <ol className="relative space-y-8 border-l border-slate/30 pl-8">
      {STEPS.map((step) => (
        <li key={step.n} className="relative">
          <span
            className="absolute -left-[2.55rem] flex h-8 w-8 items-center justify-center rounded-full bg-navy text-small font-medium text-parchment"
            aria-hidden="true"
          >
            {step.n}
          </span>
          <h3 className="text-h4 font-semibold text-navy">{step.title}</h3>
          <p className="mt-1 max-w-measure text-body text-slate">{step.body}</p>
        </li>
      ))}
    </ol>
  );
}
