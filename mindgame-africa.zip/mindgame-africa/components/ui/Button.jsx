import Link from 'next/link';

/**
 * variant "primary"   -> solid gold, for the one key action on a section
 * variant "secondary" -> outline navy, for a supporting action
 */
export default function Button({ href, children, variant = 'primary', ...props }) {
  const base =
    'inline-block rounded-sm px-6 py-3 text-small font-medium transition-colors duration-150';
  const styles =
    variant === 'primary'
      ? 'bg-gold text-navy hover:bg-gold/90'
      : 'border border-navy text-navy hover:bg-navy hover:text-parchment';

  return (
    <Link href={href} className={`${base} ${styles}`} {...props}>
      {children}
    </Link>
  );
}
