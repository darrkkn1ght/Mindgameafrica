/**
 * Deliberately plain: no all-caps eyebrow label, no accent-single-word
 * treatment. The heading and its supporting line carry the content;
 * they aren't decorated with chrome that doesn't encode information.
 */
export default function SectionHeading({ title, supporting }) {
  return (
    <div className="max-w-measure">
      <h2 className="text-h2 font-semibold text-navy">{title}</h2>
      {supporting && (
        <p className="mt-4 text-body-lg text-slate">{supporting}</p>
      )}
    </div>
  );
}
